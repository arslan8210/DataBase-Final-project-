﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using DLL.DLInterfaces;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DLL.DL
{
    public class PhoneDB : IPhoneDL
    {
        public Phones GetPhoneByModel(string model)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Phones WHERE Model = @Model";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Model", model);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if(reader.Read())
            {
                string Category = (string)reader["Category"];
                string Model = (string)reader["Model"];
                int Quantity = (int)reader["Quantity"];
                int Price = (int)reader["Price"];
                reader.Close();

                Phones phone = new SellingPhones(Category,Model,Price,Quantity);
                return phone;
            }
            return null;
        }
        public void SavePhone(Phones phone)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "INSERT INTO Phones (Category, Model, Quantity, Price) VALUES (@Category, @Model, @Quantity, @Price)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Category", phone.GetCategory());
            command.Parameters.AddWithValue("@Model", phone.GetModel());
            command.Parameters.AddWithValue("@Quantity", phone.GetQuantity());
            command.Parameters.AddWithValue("@Price", phone.GetPrice());
            command.ExecuteNonQuery();
        }

        public void DeletePhone(Phones phone)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "DELETE FROM Phones WHERE Model = @Model AND Category = @Category";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Model", phone.GetModel());
            command.Parameters.AddWithValue("@Category", phone.GetCategory());
            command.ExecuteNonQuery();
        }

        public void UpdatePhone(Phones phone)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "UPDATE Phones SET Quantity = @Quantity, Price = @Price WHERE Model = @Model AND Category = @Category";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Quantity", phone.GetQuantity());
            command.Parameters.AddWithValue("@Price", phone.GetPrice());
            command.Parameters.AddWithValue("@Model", phone.GetModel());
            command.Parameters.AddWithValue("@Category", phone.GetCategory());
            command.ExecuteNonQuery();

        }

        public List<Phones> GetAllPhones()
        {
            List<Phones> phones = new List<Phones>();
            var connection = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Phones";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string Category = reader["Category"].ToString();
                string Model = reader["Model"].ToString();
                int Quantity = Convert.ToInt32(reader["Quantity"]);
                int Price = Convert.ToInt32(reader["Price"]);
                Phones phone = new SellingPhones(Category, Model, Price, Quantity);
                phones.Add(phone);
            }
            reader.Close();
            return phones;
        }
    }
}
