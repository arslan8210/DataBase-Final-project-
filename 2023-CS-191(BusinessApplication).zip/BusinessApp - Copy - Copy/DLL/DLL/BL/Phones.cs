﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.BL
{
    public class Phones
    {
        private string Category;
        private string Model;
        public Phones(string Category, string Model)
        {
            this.Category = Category;
            this.Model = Model;
        }
        public string GetCategory()
        {
            return Category;
        }
        public void SetCategory(string Category)
        {
            this.Category = Category;
        }
        public string GetModel()
        {
            return Model;
        }
        public void SetModel(string Model)
        {
            this.Model = Model;
        }
        public virtual void SetPrice(int Price)
        {

        }
        public virtual void SetQuantity(int Quantity)
        {

        }
        public virtual int GetPrice()
        {
            return 0;
        }
        public virtual int GetQuantity()
        {
            return 0;
        }
        public virtual bool GetIsRepair()
        {
            return true;
        }
        public virtual void SetIsRepair(bool isRepair)
        {

        }
        public virtual string GetFault()
        {
            return "";
        }
        public virtual void SetIsRepair(string Fault)
        {
        }
    }
}
