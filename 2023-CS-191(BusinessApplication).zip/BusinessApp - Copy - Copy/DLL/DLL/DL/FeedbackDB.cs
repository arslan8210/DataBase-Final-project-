﻿using DLL.BL;
using System;
using System.Collections.Generic;
using DLL.DLInterfaces;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.DL
{
    public class FeedbackDB : IFeedbackDL
    {
        public Feedback GetFeedbackbyName(string name)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Feedback WHERE CustomerName = @name";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", name);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                string userName = (string)reader["CustomerName"];
                string feed = (string)reader["Feedback"];
                reader.Close();

                Feedback feedback = new Feedback(userName,feed);
                return feedback;

            }
            return null;
        }

        public void SaveFeedback(Feedback feedback)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "INSERT INTO Feedback (CustomerName,Feedback,Response) VALUES (@name,@feed,@resp)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", feedback.GetCustomerName());
            command.Parameters.AddWithValue("@feed", feedback.GetFeedback());
            command.Parameters.AddWithValue("@resp", "No Response");
            command.ExecuteNonQuery();
        }

        public void DeleteFeedback(Feedback feedback)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "DELETE FROM Feedback WHERE CustomerName = @name";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", feedback.GetCustomerName());
            command.ExecuteNonQuery();
        }

        public void UpdateFeedback(Feedback feedback)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "UPDATE Feedback SET Feedback = @feed, WHERE CustomerName = @name";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", feedback.GetCustomerName());
            command.Parameters.AddWithValue("@feed", feedback.GetFeedback());
            command.ExecuteNonQuery();
        }

        public List<Feedback> GetAllFeedbacks()
        {
            List<Feedback> feedbacks = new List<Feedback>();
            var connection = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Feedback";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string userName = (string)reader["CustomerName"];
                string feed = (string)reader["Feedback"];
                string resp = (string)reader["Response"];
                Feedback feedback = new Feedback(userName, feed,resp);
                feedbacks.Add(feedback);
            }
            reader.Close();
            return feedbacks;

        }
    }
}
