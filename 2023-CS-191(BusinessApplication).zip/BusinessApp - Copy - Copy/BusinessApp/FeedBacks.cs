﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class FeedBacks : Form
    {
        public FeedBacks()
        {
            InitializeComponent();
            PopulateGridView();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string rep = textBox2.Text;

            // Assuming Configuration.getInstance().getConnection() returns a SqlConnection
            var con = Configuration.getInstance().getConnection();
            string query = "UPDATE Feedback SET Response = @resp WHERE CustomerName = @CustomerName";
            SqlCommand sqlCommand = new SqlCommand(query, con);
            sqlCommand.Parameters.AddWithValue("@CustomerName", name);
            sqlCommand.Parameters.AddWithValue("@resp", rep);
            sqlCommand.ExecuteNonQuery();
            PopulateGridView();
        }

        private void PopulateGridView()
        {
            List <Feedback> feedBacks = ObjectHandler.GetFeedback().GetAllFeedbacks();
            DataTable dataTable = new DataTable();

            dataTable.Columns.Add("Customer Name", typeof(string));
            dataTable.Columns.Add("Feedback", typeof(string));
            dataTable.Columns.Add("Response", typeof(string));

            foreach (Feedback feedback in feedBacks)
            {
                dataTable.Rows.Add(feedback.GetCustomerName(), feedback.GetFeedback(), feedback.GetFeedbbackResponse());
            }

            dataGridView1.DataSource = dataTable;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
