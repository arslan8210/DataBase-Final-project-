﻿namespace BusinessApp
{
    partial class UserInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.usersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showAllUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllMobilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllOrdersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewPreOrdersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewMyOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteMyOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.repairingMobilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewPhonesForRepairingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showREpairingPhonesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usersToolStripMenuItem,
            this.ordresToolStripMenuItem,
            this.repairingMobilesToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.logoutToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // usersToolStripMenuItem
            // 
            this.usersToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.usersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showAllUsersToolStripMenuItem,
            this.viewAllMobilesToolStripMenuItem});
            this.usersToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usersToolStripMenuItem.Name = "usersToolStripMenuItem";
            this.usersToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.usersToolStripMenuItem.Text = "Mobiles";
            // 
            // showAllUsersToolStripMenuItem
            // 
            this.showAllUsersToolStripMenuItem.Name = "showAllUsersToolStripMenuItem";
            this.showAllUsersToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.showAllUsersToolStripMenuItem.Text = "Show All Availabe Categories";
            this.showAllUsersToolStripMenuItem.Click += new System.EventHandler(this.showAllUsersToolStripMenuItem_Click);
            // 
            // viewAllMobilesToolStripMenuItem
            // 
            this.viewAllMobilesToolStripMenuItem.Name = "viewAllMobilesToolStripMenuItem";
            this.viewAllMobilesToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.viewAllMobilesToolStripMenuItem.Text = "Show All Models";
            this.viewAllMobilesToolStripMenuItem.Click += new System.EventHandler(this.viewAllMobilesToolStripMenuItem_Click);
            // 
            // ordresToolStripMenuItem
            // 
            this.ordresToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ordresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewAllOrdersToolStripMenuItem,
            this.viewPreOrdersToolStripMenuItem,
            this.viewMyOrderToolStripMenuItem,
            this.deleteMyOrderToolStripMenuItem});
            this.ordresToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ordresToolStripMenuItem.Name = "ordresToolStripMenuItem";
            this.ordresToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.ordresToolStripMenuItem.Text = "Ordres";
            // 
            // viewAllOrdersToolStripMenuItem
            // 
            this.viewAllOrdersToolStripMenuItem.Name = "viewAllOrdersToolStripMenuItem";
            this.viewAllOrdersToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.viewAllOrdersToolStripMenuItem.Text = "Place Order";
            this.viewAllOrdersToolStripMenuItem.Click += new System.EventHandler(this.viewAllOrdersToolStripMenuItem_Click);
            // 
            // viewPreOrdersToolStripMenuItem
            // 
            this.viewPreOrdersToolStripMenuItem.Name = "viewPreOrdersToolStripMenuItem";
            this.viewPreOrdersToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.viewPreOrdersToolStripMenuItem.Text = "Place Pre-Order";
            this.viewPreOrdersToolStripMenuItem.Click += new System.EventHandler(this.viewPreOrdersToolStripMenuItem_Click);
            // 
            // viewMyOrderToolStripMenuItem
            // 
            this.viewMyOrderToolStripMenuItem.Name = "viewMyOrderToolStripMenuItem";
            this.viewMyOrderToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.viewMyOrderToolStripMenuItem.Text = "View My Order";
            this.viewMyOrderToolStripMenuItem.Click += new System.EventHandler(this.viewMyOrderToolStripMenuItem_Click);
            // 
            // deleteMyOrderToolStripMenuItem
            // 
            this.deleteMyOrderToolStripMenuItem.Name = "deleteMyOrderToolStripMenuItem";
            this.deleteMyOrderToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.deleteMyOrderToolStripMenuItem.Text = "Delete My Order";
            this.deleteMyOrderToolStripMenuItem.Click += new System.EventHandler(this.deleteMyOrderToolStripMenuItem_Click);
            // 
            // repairingMobilesToolStripMenuItem
            // 
            this.repairingMobilesToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.repairingMobilesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewPhonesForRepairingToolStripMenuItem});
            this.repairingMobilesToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.repairingMobilesToolStripMenuItem.Name = "repairingMobilesToolStripMenuItem";
            this.repairingMobilesToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.repairingMobilesToolStripMenuItem.Text = "FeedBack";
            // 
            // viewPhonesForRepairingToolStripMenuItem
            // 
            this.viewPhonesForRepairingToolStripMenuItem.Name = "viewPhonesForRepairingToolStripMenuItem";
            this.viewPhonesForRepairingToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.viewPhonesForRepairingToolStripMenuItem.Text = "Give FeedBack";
            this.viewPhonesForRepairingToolStripMenuItem.Click += new System.EventHandler(this.viewPhonesForRepairingToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.logoutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showREpairingPhonesToolStripMenuItem});
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.logoutToolStripMenuItem.Text = "Repairing Phones";
            // 
            // showREpairingPhonesToolStripMenuItem
            // 
            this.showREpairingPhonesToolStripMenuItem.Name = "showREpairingPhonesToolStripMenuItem";
            this.showREpairingPhonesToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.showREpairingPhonesToolStripMenuItem.Text = "Phone for Repairing";
            // 
            // logoutToolStripMenuItem1
            // 
            this.logoutToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.logoutToolStripMenuItem1.Checked = true;
            this.logoutToolStripMenuItem1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.logoutToolStripMenuItem1.Name = "logoutToolStripMenuItem1";
            this.logoutToolStripMenuItem1.Size = new System.Drawing.Size(54, 20);
            this.logoutToolStripMenuItem1.Text = "logout";
            this.logoutToolStripMenuItem1.Click += new System.EventHandler(this.logoutToolStripMenuItem1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::BusinessApp.Properties.Resources.phones_with_cogs_inside;
            this.pictureBox2.Location = new System.Drawing.Point(0, 27);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(800, 423);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // UserInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UserInterface";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UserInterface";
            this.Load += new System.EventHandler(this.UserInterface_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem usersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showAllUsersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllMobilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllOrdersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewPreOrdersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem repairingMobilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewPhonesForRepairingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showREpairingPhonesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStripMenuItem viewMyOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteMyOrderToolStripMenuItem;
    }
}