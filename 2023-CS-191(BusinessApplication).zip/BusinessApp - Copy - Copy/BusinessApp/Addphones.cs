﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class Addphones : Form
    {
        public Addphones()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {
            string category = textBox1.Text;
            string model = textBox2.Text;
            int quantity = int.Parse(textBox3.Text);
            int price = int.Parse(textBox4.Text);
            Phones phone = new SellingPhones(category, model, price, quantity);
            ObjectHandler.GetPhone().SavePhone(phone);
            MessageBox.Show("Phone added successfully");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
