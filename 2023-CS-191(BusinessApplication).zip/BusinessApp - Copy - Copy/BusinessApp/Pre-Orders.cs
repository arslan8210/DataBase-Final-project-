﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class Pre_Orders : Form
    {
        public Pre_Orders()
        {
            InitializeComponent();
            PopulateDataGridView();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void PopulateDataGridView()
        {
            List<PreOrders> preOrders = ObjectHandler.GetPreOrder().GetAllPreOrders();
            DataTable dataTable = new DataTable();

            dataTable.Columns.Add("Customer Name", typeof(string));
            dataTable.Columns.Add("PreOrder Model", typeof(string));
            dataTable.Columns.Add("PreOrder Category", typeof(string));

            foreach (var preOrder in preOrders)
            {
                dataTable.Rows.Add(preOrder.GetCustomerName(), preOrder.GetPreOrderModel(), preOrder.GetPreOrderCategory());
            }
            dataGridView1.DataSource = dataTable;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
