﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.DLInterfaces
{
    public interface ILogInDL
    {
        LogIn GetuserByName(string name);

        void SaveUser(LogIn logIn);

        void DeleteUser(LogIn logIn);

        void UpdateUser(LogIn logIn);

        List<LogIn> GetAllUsers();
    }
}
