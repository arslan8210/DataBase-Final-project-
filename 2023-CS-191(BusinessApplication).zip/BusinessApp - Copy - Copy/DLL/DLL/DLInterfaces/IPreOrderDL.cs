﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.DLInterfaces
{
    public interface IPreOrderDL
    {
        PreOrders GetPreOrderByModelAndCategory(string model,string category);

        void SavePreOrder(PreOrders orders);

        void DeletePreOrder(PreOrders orders);

        void UpdatePreOrder(PreOrders orders);

        List<PreOrders> GetAllPreOrders();
    }
}
