﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class ViewAllOrdres : Form
    {
        public ViewAllOrdres()
        {
            InitializeComponent();
            PopulateDataGridView();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void PopulateDataGridView()
        {
            List<Orders> preOrders = ObjectHandler.GetOrder().GetAllOrders();
            DataTable dataTable = new DataTable();

            dataTable.Columns.Add("Customer Name", typeof(string));
            dataTable.Columns.Add("Order Model", typeof(string));
            dataTable.Columns.Add("Order Category", typeof(string));

            foreach (var Order in preOrders)
            {
                dataTable.Rows.Add(Order.GetCustomerName(),Order.GetOrderModel(), Order.GetOrderCategory());
            }
            dataGridView1.DataSource = dataTable;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
