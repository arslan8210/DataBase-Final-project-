﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.BL
{
    public class Feedback
    {
        private string CustomerName;
        private string feedback;
        private string Response;

        public Feedback(string CustomerName, string feedback)
        {
            this.CustomerName = CustomerName;
            this.feedback = feedback;
            Response = "No Response";
        }

        public Feedback(string CustomerName, string feedback,string response)
        {
            this.CustomerName = CustomerName;
            this.feedback = feedback;
            Response = response;
        }
        public string GetCustomerName()
        {
            return CustomerName;
        }
        public string GetFeedback()
        {
            return feedback;
        }
        public void SetCustomerName(string customerName)
        {
            this.CustomerName = customerName;
        }
        public void SetFeedback(string Feedback)
        {
            this.feedback = Feedback;
        }
        public string GetFeedbbackResponse()
        {
            return Response;
        }
        public void SetFeedBackResponse(string Response)
        {
            this.Response = Response;
        }
    }
}
