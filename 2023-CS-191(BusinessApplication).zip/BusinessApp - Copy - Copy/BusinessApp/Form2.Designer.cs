﻿namespace BusinessApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.usersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showAllUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllMobilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateMobilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteMobileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feedBacksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllFeedBacksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllOrdersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewPreOrdersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.repairingMobilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewPhonesForRepairingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showREpairingPhonesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usersToolStripMenuItem,
            this.feedBacksToolStripMenuItem,
            this.ordresToolStripMenuItem,
            this.repairingMobilesToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.logoutToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // usersToolStripMenuItem
            // 
            this.usersToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.usersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showAllUsersToolStripMenuItem,
            this.viewAllMobilesToolStripMenuItem,
            this.updateMobilesToolStripMenuItem,
            this.deleteMobileToolStripMenuItem});
            this.usersToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usersToolStripMenuItem.Name = "usersToolStripMenuItem";
            this.usersToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.usersToolStripMenuItem.Text = "Mobiles";
            this.usersToolStripMenuItem.Click += new System.EventHandler(this.usersToolStripMenuItem_Click_1);
            // 
            // showAllUsersToolStripMenuItem
            // 
            this.showAllUsersToolStripMenuItem.Name = "showAllUsersToolStripMenuItem";
            this.showAllUsersToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.showAllUsersToolStripMenuItem.Text = "Add Mobiles";
            this.showAllUsersToolStripMenuItem.Click += new System.EventHandler(this.showAllUsersToolStripMenuItem_Click);
            // 
            // viewAllMobilesToolStripMenuItem
            // 
            this.viewAllMobilesToolStripMenuItem.Name = "viewAllMobilesToolStripMenuItem";
            this.viewAllMobilesToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.viewAllMobilesToolStripMenuItem.Text = "View All mobiles";
            this.viewAllMobilesToolStripMenuItem.Click += new System.EventHandler(this.viewAllMobilesToolStripMenuItem_Click);
            // 
            // updateMobilesToolStripMenuItem
            // 
            this.updateMobilesToolStripMenuItem.Name = "updateMobilesToolStripMenuItem";
            this.updateMobilesToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.updateMobilesToolStripMenuItem.Text = "update mobiles";
            this.updateMobilesToolStripMenuItem.Click += new System.EventHandler(this.updateMobilesToolStripMenuItem_Click);
            // 
            // deleteMobileToolStripMenuItem
            // 
            this.deleteMobileToolStripMenuItem.Name = "deleteMobileToolStripMenuItem";
            this.deleteMobileToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.deleteMobileToolStripMenuItem.Text = "Delete Mobile";
            this.deleteMobileToolStripMenuItem.Click += new System.EventHandler(this.deleteMobileToolStripMenuItem_Click);
            // 
            // feedBacksToolStripMenuItem
            // 
            this.feedBacksToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.feedBacksToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewAllFeedBacksToolStripMenuItem,
            this.deleteUserToolStripMenuItem});
            this.feedBacksToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feedBacksToolStripMenuItem.Name = "feedBacksToolStripMenuItem";
            this.feedBacksToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.feedBacksToolStripMenuItem.Text = "Users";
            this.feedBacksToolStripMenuItem.Click += new System.EventHandler(this.feedBacksToolStripMenuItem_Click);
            // 
            // viewAllFeedBacksToolStripMenuItem
            // 
            this.viewAllFeedBacksToolStripMenuItem.Name = "viewAllFeedBacksToolStripMenuItem";
            this.viewAllFeedBacksToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.viewAllFeedBacksToolStripMenuItem.Text = "View All users";
            this.viewAllFeedBacksToolStripMenuItem.Click += new System.EventHandler(this.viewAllFeedBacksToolStripMenuItem_Click);
            // 
            // deleteUserToolStripMenuItem
            // 
            this.deleteUserToolStripMenuItem.Name = "deleteUserToolStripMenuItem";
            this.deleteUserToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.deleteUserToolStripMenuItem.Text = "Delete User";
            this.deleteUserToolStripMenuItem.Click += new System.EventHandler(this.deleteUserToolStripMenuItem_Click);
            // 
            // ordresToolStripMenuItem
            // 
            this.ordresToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ordresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewAllOrdersToolStripMenuItem,
            this.viewPreOrdersToolStripMenuItem});
            this.ordresToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ordresToolStripMenuItem.Name = "ordresToolStripMenuItem";
            this.ordresToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.ordresToolStripMenuItem.Text = "Ordres";
            // 
            // viewAllOrdersToolStripMenuItem
            // 
            this.viewAllOrdersToolStripMenuItem.Name = "viewAllOrdersToolStripMenuItem";
            this.viewAllOrdersToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.viewAllOrdersToolStripMenuItem.Text = "View All Orders";
            this.viewAllOrdersToolStripMenuItem.Click += new System.EventHandler(this.viewAllOrdersToolStripMenuItem_Click);
            // 
            // viewPreOrdersToolStripMenuItem
            // 
            this.viewPreOrdersToolStripMenuItem.Name = "viewPreOrdersToolStripMenuItem";
            this.viewPreOrdersToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.viewPreOrdersToolStripMenuItem.Text = "View Pre-Orders";
            this.viewPreOrdersToolStripMenuItem.Click += new System.EventHandler(this.viewPreOrdersToolStripMenuItem_Click);
            // 
            // repairingMobilesToolStripMenuItem
            // 
            this.repairingMobilesToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.repairingMobilesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewPhonesForRepairingToolStripMenuItem});
            this.repairingMobilesToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.repairingMobilesToolStripMenuItem.Name = "repairingMobilesToolStripMenuItem";
            this.repairingMobilesToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.repairingMobilesToolStripMenuItem.Text = "FeedBack";
            this.repairingMobilesToolStripMenuItem.Click += new System.EventHandler(this.repairingMobilesToolStripMenuItem_Click);
            // 
            // viewPhonesForRepairingToolStripMenuItem
            // 
            this.viewPhonesForRepairingToolStripMenuItem.Name = "viewPhonesForRepairingToolStripMenuItem";
            this.viewPhonesForRepairingToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.viewPhonesForRepairingToolStripMenuItem.Text = "View FeedBacks";
            this.viewPhonesForRepairingToolStripMenuItem.Click += new System.EventHandler(this.viewPhonesForRepairingToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.logoutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showREpairingPhonesToolStripMenuItem});
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.logoutToolStripMenuItem.Text = "Repairing Phones";
            // 
            // showREpairingPhonesToolStripMenuItem
            // 
            this.showREpairingPhonesToolStripMenuItem.Name = "showREpairingPhonesToolStripMenuItem";
            this.showREpairingPhonesToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.showREpairingPhonesToolStripMenuItem.Text = "Show Repairing Phones";
            this.showREpairingPhonesToolStripMenuItem.Click += new System.EventHandler(this.showREpairingPhonesToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem1
            // 
            this.logoutToolStripMenuItem1.Name = "logoutToolStripMenuItem1";
            this.logoutToolStripMenuItem1.Size = new System.Drawing.Size(54, 20);
            this.logoutToolStripMenuItem1.Text = "logout";
            this.logoutToolStripMenuItem1.Click += new System.EventHandler(this.logoutToolStripMenuItem1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BusinessApp.Properties.Resources.pngtree_blue_mobile_phone_and_mockup_shop_on_blue_pedestals_overlap_image_1102538;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem usersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showAllUsersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feedBacksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllFeedBacksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllOrdersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewPreOrdersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem repairingMobilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewPhonesForRepairingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllMobilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateMobilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteMobileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showREpairingPhonesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem1;
    }
}