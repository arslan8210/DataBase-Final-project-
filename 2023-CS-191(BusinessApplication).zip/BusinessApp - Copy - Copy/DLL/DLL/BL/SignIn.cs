﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.BL
{
    public class SignIn : LogIn
    {
        public SignIn(string UserName, string Password) : base(UserName, Password)
        {

        }
    }
}
