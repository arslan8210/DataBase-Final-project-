﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class update : Form
    {
        public update()
        {
            InitializeComponent();
        }

        private void update_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string category = textBox3.Text;
            string model = textBox4.Text;
            int quan = int.Parse(textBox5.Text);
            int price = int.Parse(textBox6.Text);
            Phones phones = new SellingPhones(category, model, price, quan);
            ObjectHandler.GetPhone().UpdatePhone(phones);
            MessageBox.Show("Updated successfully");
        }
    }
}
