﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.BL
{
    public class LogIn
    {

        protected string UserName;
        protected string Password;

        public LogIn(string userName, string Password)
        {
            this.UserName = userName;
            this.Password = Password;
        }

        public virtual string GetRole()
        {
            return "";
        }
        public virtual void SetRole(string role)
        {
        }
        public string GetUserName()
        {
            return UserName;
        }
        public void SetUserName(string userName)
        {
            UserName = userName;
        }
        public void SetPassword(string password)
        {
            Password = password;
        }

        public string GetPassword()
        {
            return this.Password;
        } 
    }
}
