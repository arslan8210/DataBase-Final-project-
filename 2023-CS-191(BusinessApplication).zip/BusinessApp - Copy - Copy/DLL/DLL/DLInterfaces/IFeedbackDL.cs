﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.DLInterfaces
{
    public interface IFeedbackDL
    {
        Feedback GetFeedbackbyName(string name);

        void SaveFeedback(Feedback feedback);

        void DeleteFeedback(Feedback feedback);

        void UpdateFeedback(Feedback feedback);

        List<Feedback> GetAllFeedbacks();
    }
}
