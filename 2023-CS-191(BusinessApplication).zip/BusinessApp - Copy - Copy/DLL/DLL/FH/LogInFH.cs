﻿using System;
using System.Collections.Generic;
using System.Linq;
using DLL.DLInterfaces;
using System.Text;
using System.Threading.Tasks;
using DLL.BL;
using System.IO;

namespace DLL.FH
{
    public class LogInFH : ILogInDL
    {

        private string filePath;

        public LogInFH(string path)
        {
            filePath = path;

            if (!File.Exists(filePath))
            {
                File.Create(filePath);
            }
        }
        public LogIn GetuserByName(string name)
        {
            LogIn user = null;
            try
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 2 && parts[0].Trim() == name)
                    {
                        user = new SignUp(parts[2].Trim(),parts[0].Trim(), parts[1].Trim());
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading file: {ex.Message}");
            }

            return user;
        }

        public void SaveUser(LogIn logIn)
        {
            string userData = $"{logIn.GetUserName()},{logIn.GetPassword()},{logIn.GetRole()}";

            File.AppendAllText(filePath, $"{userData}\n");
        }

        public void DeleteUser(LogIn logIn)
        {
            string[] lines = File.ReadAllLines(filePath);
            var updatedContent = new System.Text.StringBuilder();

            foreach (string line in lines)
            {
                string[] parts = line.Split(',');

                if (parts.Length >= 1 && parts[0].Trim() == logIn.GetUserName())
                {
                    continue;
                }

                updatedContent.AppendLine(line);
            }

            File.WriteAllText(filePath, updatedContent.ToString());
        }

        public void UpdateUser(LogIn logIn)
        {

        }

        public List<LogIn> GetAllUsers()
        {
            List<LogIn> users = new List<LogIn>();

            if (!File.Exists(filePath))
            {
                Console.WriteLine("File does not exist.");
                return users; 
            }

            string[] lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
            {
                string[] parts = line.Split(',');

                if (parts.Length >= 3)
                {
                    LogIn user = new SignUp(parts[2].Trim(),parts[0].Trim(), parts[1].Trim());
                    users.Add(user);
                }
            }

            return users;
        }
    }
    
}
