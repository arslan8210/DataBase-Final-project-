﻿using DLL.BL;
using System;
using System.Collections.Generic;
using DLL.DLInterfaces;
using System.Data.SqlClient;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DLL.DL
{
    public class OrderDB : IOrderDL
    {
        public Orders GetOrderByModelAndCategory(string model, string category)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Orders WHERE Model = @Model and Category = @category";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Model", model);
            command.Parameters.AddWithValue("@category",  category);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                string customerName = (string)reader["CustomerName"];
                string Model = (string)reader["Model"];
                string Category = (string)reader["Category"];
                reader.Close();

                Orders order = new Orders(customerName,Category,Model);
                return order;

            }
            return null;
        }

        public void SaveOrder(Orders orders)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "INSERT INTO Orders (CustomerName,Category, Model) VALUES (@CustomerName,@Category, @Model)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Category", orders.GetOrderCategory());
            command.Parameters.AddWithValue("@Model", orders.GetOrderModel());
            command.Parameters.AddWithValue("@CustomerName", orders.GetCustomerName());
            command.ExecuteNonQuery();
        }

        public void DeleteOrder(Orders orders)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "DELETE FROM Orders WHERE Model = @Model AND Category = @Category";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Model", orders.GetOrderModel());
            command.Parameters.AddWithValue("@Category", orders.GetOrderCategory());
            command.ExecuteNonQuery();
        }

        public void UpdateOrder(Orders orders)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "UPDATE Orders SET CustomerName = @CustomerName WHERE Model = @Model AND Category = @Category";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@CustomerName", orders.GetCustomerName());
            command.Parameters.AddWithValue("@Model", orders.GetOrderModel());
            command.Parameters.AddWithValue("@Category", orders.GetOrderCategory());
            command.ExecuteNonQuery();
        }

        public List<Orders> GetAllOrders()
        {
            List<Orders> orders = new List<Orders>();
            var connection = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Orders";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string customerName = (string)reader["CustomerName"];
                string Model = (string)reader["Model"];
                string Category = (string)reader["Category"];
                Orders order = new Orders(customerName, Category, Model);
                orders.Add(order);
            }
            reader.Close();
            return orders;
        }
    }
}
