﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.BL
{
    public class PreOrders
    {
        private string CustomerName;
        private string PreOrderModel;
        private string PreOrderCategory;
        public PreOrders(string CustomerName, string PreOrderCategory,string PreOrderModel)
        {
            this.CustomerName = CustomerName;
            this.PreOrderModel = PreOrderModel;
            this.PreOrderCategory = PreOrderCategory; 

        }
        public string GetCustomerName()
        {
            return this.CustomerName;
        }
        public string GetPreOrderModel()
        {
            return this.PreOrderModel;
        }

        public string GetPreOrderCategory()
        {
            return this.PreOrderCategory;
        }

    }
}
