﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.BL
{
    public class SellingPhones : Phones
    {
        private int Price;
        private int Quantity;
        public SellingPhones(string Category, string Model, int Price, int Quantity) : base(Category, Model)
        {
            this.Price = Price;
            this.Quantity = Quantity;

        }

        public override int GetPrice()
        {
            return this.Price;
        }
        public override int GetQuantity()
        {
            return this.Quantity;
        }

        public override void SetPrice(int Price)
        {
            this.Price = Price;
        }
        public override void SetQuantity(int Quantity)
        {
            this.Quantity = Quantity;
        }
    }
}
