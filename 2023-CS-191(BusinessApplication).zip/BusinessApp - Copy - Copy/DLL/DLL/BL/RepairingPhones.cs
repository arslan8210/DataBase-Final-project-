﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.BL
{
    public class RepairingPhones : Phones
    {
        private string Fault;
        public RepairingPhones(string Fault, string Category, string Model) : base(Category, Model)
        {
            this.Fault = Fault;
        }
        public override string GetFault()
        {
            return Fault;
        }
        public override void SetIsRepair(string Fault)
        {
            this.Fault = Fault;
        }
    }
}
