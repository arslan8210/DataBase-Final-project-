﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class showAllUsers : Form
    {
        public showAllUsers()
        {
            InitializeComponent();
            Populate();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void Populate()
        {
            DataTable dataTable = new DataTable();

            dataTable.Columns.Add("Username", typeof(string));
            dataTable.Columns.Add("Password", typeof(string));
            dataTable.Columns.Add("Role", typeof(string));

            List<LogIn> users = ObjectHandler.GetUser().GetAllUsers();

            foreach (var user in users)
            {
                dataTable.Rows.Add(user.GetUserName(), user.GetPassword(), user.GetRole());
            }

            dataGridView1.DataSource = dataTable;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }
    }
}
