﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void feedBacksToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void viewPhonesForRepairingToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void usersToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void showAllUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Addphones addphones = new Addphones();
            //this.Hide();
            addphones.ShowDialog();
            this.Show();

        }

        private void viewAllMobilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowPhones showPhones = new ShowPhones();
            //this.Hide();
            showPhones.ShowDialog();
            this.Show();

        }

        private void updateMobilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            update update = new update();
            //this.Hide();
            update.ShowDialog();
            this.Show();

        }

        private void deleteMobileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteMobiles delete = new DeleteMobiles();
            //this.Hide();
            delete.ShowDialog();
            this.Show();

        }

        private void viewAllFeedBacksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showAllUsers showAllUsers = new showAllUsers();
            //this.Hide();
            showAllUsers.ShowDialog();
            this.Show();

        }

        private void deleteUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteUser delete = new DeleteUser();
            //this.Hide(); 
            delete.ShowDialog();
            this.Show();

        }

        private void viewAllOrdersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewAllOrdres viewAllOrdres = new ViewAllOrdres();
            //this.Hide();
            viewAllOrdres.ShowDialog();
            this.Show();

        }

        private void viewPreOrdersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Pre_Orders viewPreOrders = new Pre_Orders();
            //this.Hide();
            viewPreOrders.ShowDialog();
            this.Show();

        }

        private void repairingMobilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FeedBacks feedBacks = new FeedBacks();
            feedBacks.ShowDialog();
            this.Show();
        }

        private void showREpairingPhonesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowPhones showPhones = new ShowPhones();
            //this.Hide();
            showPhones.ShowDialog();
            this.Show();

        }

        private void logoutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
