﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class DeleteUser : Form
    {
        public DeleteUser()
        {
            InitializeComponent();
        }

        private void DeleteUser_Load(object sender, EventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            LogIn login = new LogIn(name,"");
            ObjectHandler.GetUser().DeleteUser(login);
            ObjectHandler.GetFHUser().DeleteUser(login);
            MessageBox.Show("User deleted successfully");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
