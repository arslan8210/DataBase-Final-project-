﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.BL
{
    public class SignUp : LogIn
    {
        private string Role;

        public SignUp(string role, string UserName, string Password) : base(UserName, Password)

        {
            this.Role = role;
        }

        public override string GetRole()
        {
            return this.Role;
        }
        public override void SetRole(string role)
        {
            this.Role = role;
        }
    }
}
