use MyProject


create table Phones(
	PhoneId int identity(1,1) primary key,
	Category varchar(100) not null,
	Model varchar(100) not null,
	Quantity int,
	Price decimal(10, 2)
)


create table Users(
	Username varchar(100) primary key,
	Password varchar(100),
	Role varchar(100)
)

create table Orders(
	CustomerName varchar(100),
	Category varchar(100) not null,
	Model varchar(100) not null,
	Foreign key (CustomerName) References Users(Username)
)

create table PreOrders(
	CustomerName varchar(100),
	Category varchar(100) not null,
	Model varchar(100) not null,
	Foreign key (CustomerName) References Users(Username)
)

create table Feedback(
	CustomerName varchar(100),
	Feedback varchar(max) not null
	Foreign key (CustomerName) References Users(Username)
)





