﻿using DLL.BL;
using DLL.DLInterfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DLL.DL
{
    public class LogInDB : ILogInDL
    {
        public LogIn GetuserByName(string name)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Users WHERE UserName = @name";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", name);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                string userName = (string)reader["UserName"];
                string password = (string)reader["Password"];
                string role = (string)reader["Role"];
                reader.Close();
                LogIn logIn = new SignUp(role, userName, password);
                return logIn;

            }
            return null;
        }

        public void SaveUser(LogIn logIn)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "INSERT INTO Users (UserName,Password,Role) VALUES (@name,@pass, @role)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", logIn.GetUserName());
            command.Parameters.AddWithValue("@pass", logIn.GetPassword());
            command.Parameters.AddWithValue("@role", logIn.GetRole());
            command.ExecuteNonQuery();
        }

        public void DeleteUser(LogIn logIn)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "DELETE FROM Users WHERE UserName = @name";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", logIn.GetUserName());
            command.ExecuteNonQuery();
        }

        public void UpdateUser(LogIn logIn)
        {
            var connection = Configuration.getInstance().getConnection();
            string query = "UPDATE Users SET Password = @pass,Role=@role WHERE UserName = @name";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@pass", logIn.GetPassword());
            command.Parameters.AddWithValue("@role", logIn.GetRole());
            command.Parameters.AddWithValue("@name", logIn.GetUserName());
            command.ExecuteNonQuery();
        }

        public List<LogIn> GetAllUsers()
        {
            List<LogIn> users = new List<LogIn>();
            var connection = Configuration.getInstance().getConnection();
            string query = "SELECT * FROM Users";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string userName = (string)reader["UserName"];
                string password = (string)reader["Password"];
                string role = (string)reader["Role"];
                LogIn logIn = new SignUp(role, userName, password);
                users.Add(logIn);
            }

            reader.Close();
            return users;
        }
    }
}
