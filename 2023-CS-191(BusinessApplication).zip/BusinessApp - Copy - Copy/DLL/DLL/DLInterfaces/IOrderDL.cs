﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.DLInterfaces
{
    public interface IOrderDL
    {
        Orders GetOrderByModelAndCategory(string model,string category);

        void SaveOrder(Orders orders);

        void DeleteOrder(Orders orders);

        void UpdateOrder(Orders orders);

        List<Orders> GetAllOrders();
    }
}
