﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using DLL.DLInterfaces;
using System.Text;
using System.Threading.Tasks;

namespace DLL.DL
{
    public class PreOrderDB : IPreOrderDL
    {
            public PreOrders GetPreOrderByModelAndCategory(string model, string category)
            {
                var connection = Configuration.getInstance().getConnection();
                string query = "SELECT * FROM PreOrders WHERE Model = @Model and Category = @category";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Model", model);
                command.Parameters.AddWithValue("@category", category);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    string customerName = (string)reader["CustomerName"];
                    string Category = (string)reader["Category"];
                    string Model = (string)reader["Model"];
                reader.Close();

                PreOrders order = new PreOrders(customerName, Category, Model);
                    return order;

                }
                return null;
            }

            public void SavePreOrder(PreOrders orders)
            {
                var connection = Configuration.getInstance().getConnection();
                string query = "INSERT INTO PreOrders (CustomerName,Category, Model) VALUES (@CustomerName,@Category, @Model)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Category", orders.GetPreOrderCategory());
                command.Parameters.AddWithValue("@Model", orders.GetPreOrderModel());
                command.Parameters.AddWithValue("@CustomerName", orders.GetCustomerName());
                command.ExecuteNonQuery();
            }

            public void DeletePreOrder(PreOrders orders)
            {
                var connection = Configuration.getInstance().getConnection();
                string query = "DELETE FROM PreOrders WHERE Model = @Model AND Category = @Category";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Model", orders.GetPreOrderModel());
                command.Parameters.AddWithValue("@Category", orders.GetPreOrderCategory());
                command.ExecuteNonQuery();
            }

            public void UpdatePreOrder(PreOrders orders)
            {
                var connection = Configuration.getInstance().getConnection();
                string query = "UPDATE PreOrders SET CustomerName = @CustomerName WHERE Model = @Model AND Category = @Category";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CustomerName", orders.GetCustomerName());
                command.Parameters.AddWithValue("@Model", orders.GetPreOrderModel());
                command.Parameters.AddWithValue("@Category", orders.GetPreOrderCategory());
                command.ExecuteNonQuery();
            }

            public List<PreOrders> GetAllPreOrders()
            {
                List<PreOrders> orders = new List<PreOrders>();
                var connection = Configuration.getInstance().getConnection();
                string query = "SELECT * FROM PreOrders";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string customerName = (string)reader["CustomerName"];
                    string Model = (string)reader["Model"];
                    string Category = (string)reader["Category"];
                    PreOrders order = new PreOrders(customerName, Category, Model);
                    orders.Add(order);
                }
                reader.Close();
                return orders;
            }
    }
}
