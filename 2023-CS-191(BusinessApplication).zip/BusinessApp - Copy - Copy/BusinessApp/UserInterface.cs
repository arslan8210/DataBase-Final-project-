﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class UserInterface : Form
    {
        public UserInterface()
        {
            InitializeComponent();
        }

        private void UserInterface_Load(object sender, EventArgs e)
        {

        }

        private void viewAllMobilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowPhones phones = new ShowPhones();
            phones.Show();
            this.Show();

        }

        private void viewAllOrdersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PlaceOrderUser user = new PlaceOrderUser();
            //this.Hide();
            user.ShowDialog();
            this.Show();

        }

        private void viewPreOrdersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Pre_OrderUser user = new Pre_OrderUser();
            //this.Hide();
            user.ShowDialog();
            this.Show();

        }

        private void viewMyOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewAllOrdres viewAllOrdres = new ViewAllOrdres();
            //this.Hide();
            viewAllOrdres.ShowDialog();
            this.Show();
        }

        private void deleteMyOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteOrderUser user = new DeleteOrderUser();
            //this.Hide();
            user.ShowDialog();
            this.Show();
        }

        private void viewPhonesForRepairingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GiveFeedackUser user = new GiveFeedackUser();
            //this.Hide();
            user.ShowDialog();
            this.Show();
        }

        private void logoutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void showAllUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
