﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.BL
{
    public class Orders
    {
        private string CustomerName;
        private string OrderCategory;
        private string OrdrerModel;

        public Orders(string CustomerName, string OrderCategory, string OrderModel)
        {
            this.CustomerName = CustomerName;
            this.OrderCategory = OrderCategory;
            this.OrdrerModel = OrderModel;
        }
        public string GetCustomerName()

        {
            return CustomerName;

        }
        public string GetOrderCategory()
        {
            return OrderCategory;
        }
        public string GetOrderModel()
        {
            return OrdrerModel;
        }
    }
}
