﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class GiveFeedackUser : Form
    {
        public GiveFeedackUser()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string feedback = textBox2.Text;
            Feedback feedback1 = new Feedback(name, feedback);
            ObjectHandler.GetFeedback().SaveFeedback(feedback1);
            MessageBox.Show("Feedback submitted successfully");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
