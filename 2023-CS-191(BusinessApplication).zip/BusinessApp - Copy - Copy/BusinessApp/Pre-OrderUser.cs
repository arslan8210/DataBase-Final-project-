﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class Pre_OrderUser : Form
    {
        public Pre_OrderUser()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string cat = textBox2.Text;
            string mod = textBox3.Text;
            PreOrders orders = new PreOrders(name, cat, mod);
            ObjectHandler.GetPreOrder().SavePreOrder(orders);
            MessageBox.Show("PreOrdered successfully");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
