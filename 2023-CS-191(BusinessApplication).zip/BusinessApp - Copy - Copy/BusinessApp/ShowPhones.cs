﻿using DLL.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class ShowPhones : Form
    {
        public ShowPhones()
        {
            InitializeComponent();
            Populate();
        }

        private void ShowPhones_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void Populate()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("Category", typeof(string));
            dataTable.Columns.Add("Model", typeof(string));
            dataTable.Columns.Add("Quantity", typeof(int));
            dataTable.Columns.Add("Price", typeof(decimal));

            List<Phones> phones = ObjectHandler.GetPhone().GetAllPhones();

            foreach (var phone in phones)
            {
                dataTable.Rows.Add(phone.GetCategory(), phone.GetModel(), phone.GetQuantity(), phone.GetPrice());
            }

            dataGridView1.DataSource = dataTable;

        }
    }
}
