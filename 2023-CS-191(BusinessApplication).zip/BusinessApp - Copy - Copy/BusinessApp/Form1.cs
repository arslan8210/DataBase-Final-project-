﻿using DLL.BL;
using DLL.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string password = textBox2.Text;
            LogIn log = ObjectHandler.GetUser().GetuserByName(name);
            if(log != null)
            {
                if (log.GetRole() == "user")
                {
                    UserInterface userInterface = new UserInterface();
                    this.Hide();
                    userInterface.ShowDialog();
                    this.Show();


                }
                else if (log.GetRole() == "admin")
                {
                    Form2 form2 = new Form2();
                    this.Hide();
                    form2.ShowDialog();
                    this.Show();

                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string password = textBox2.Text;
            string role = textBox3.Text;
            LogIn logIn = new SignUp(role,name, password);
            ObjectHandler.GetUser().SaveUser(logIn);
            ObjectHandler.GetFHUser().SaveUser(logIn);
            MessageBox.Show("User added successfully");
            clearTextBoxes();
        }

        private void clearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
