﻿using DLL.DL;
using DLL.DLInterfaces;
using DLL.FH;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessApp
{
    internal class ObjectHandler
    {
        private static ILogInDL logIn = new LogInDB();

        private static IPhoneDL phone = new PhoneDB();

        private static IOrderDL order = new OrderDB();

        private static IFeedbackDL feedback = new FeedbackDB();

        private static IPreOrderDL preOrder = new PreOrderDB();

        private static ILogInDL loginfh = new LogInFH("users.txt");


        public static ILogInDL GetUser()
        {
            return logIn;
        }

        public static ILogInDL GetFHUser()
        {
            return loginfh;
        }

        public static IPhoneDL GetPhone() {  return phone; }

        public static IOrderDL GetOrder() {  return order; }

        public static IFeedbackDL GetFeedback() { return feedback; }

        public static IPreOrderDL GetPreOrder() { return preOrder; }

    }
}
